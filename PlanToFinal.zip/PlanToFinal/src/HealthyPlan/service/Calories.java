package HealthyPlan.service;

public class Calories {

}
