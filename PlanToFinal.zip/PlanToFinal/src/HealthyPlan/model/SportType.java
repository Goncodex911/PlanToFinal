package HealthyPlan.model;

public class SportType {

}
