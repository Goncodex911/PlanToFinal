package HealthyPlan.model;

public class UserProfile {

}
